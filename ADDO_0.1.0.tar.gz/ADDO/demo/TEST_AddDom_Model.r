
rm(list=ls());options(stringsAsFactors=FALSE)

# [1] Load library #
library(ADDO)

# [2] Specify directory and covariates types variable # 
indir = "data"; outdir = "data"
covariates_types = c("n","f"); names(covariates_types) = c("sex","batch")

# [3] Use three functions one by one #
ADDO_AddDom1_QC(indir=indir, outdir=outdir, Input_name="TEST", Input_type="PLINK", Kinship_type="GCTA_ad", Phe_ResDone = F, Phe_NormDone = F, Normal_method = "QUANTILE", covariates_sum=5, covariates_types=covariates_types, Phe_IndMinimum = 200, Phe_Extreme = 5, GT_maf = 0.05, GT_missing = 0.1, num_nodes=5)

ADDO_AddDom2_Pvalue(indir=indir, outdir=outdir, Input_name="TEST", Kinship_type="GCTA_ad", VarComponent_Method="GCTA_ad", Run_separated = T, covariates_sum=5, Phe_IndMinimum=200, GT_IndMinimum=10, matrix_acceleration = T, logP_threshold = 1, num_nodes=5)

ADDO_AddDom3_Plot(outdir=outdir, covariates_sum=5, RegionMan_chr_whole=F, RegionMan_chr_region = 2000000, chrs_sum = 19, num_nodes=5)

ADDO_AddDom4_IntePlot(outdir=outdir, covariates_sum=5, RegionMan_chr_whole=F, RegionMan_chr_region = 2000000, chrs_sum = 19, num_nodes=5)